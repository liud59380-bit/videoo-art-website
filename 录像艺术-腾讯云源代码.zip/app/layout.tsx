import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "录像艺术：当影像开始观看自己",
  description: "数媒261314课程小组作业：通过时间轴、循环、实时反馈与多屏实验理解录像艺术。",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  );
}
