import VideoArtExperience from "@/components/VideoArtExperience";

export default function Page() {
  return <VideoArtExperience />;
}
