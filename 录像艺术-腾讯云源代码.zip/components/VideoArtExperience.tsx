"use client";

import { useCallback, useEffect, useRef, useState } from "react";

type NodeProps = {
  id: string;
  kicker: string;
  title: string;
  className?: string;
  children: React.ReactNode;
};

const chapterLinks = [
  ["首页", "home"],
  ["发展脉络", "history"],
  ["核心特点", "characteristics"],
  ["表现形式", "forms"],
  ["代表作品", "works"],
  ["数字影响", "impact"],
  ["结论 / 来源", "sources"],
] as const;

const timeline = [
  {
    year: "1965–67",
    device: "便携摄像机",
    title: "录像从电视台走向街道",
    text: "Portapak 把录制设备从大型演播室系统变成艺术家能够携带、负担并在低照度环境使用的工具。拍摄者、表演者和观看者第一次可以在同一现场快速交换角色。",
    effect: "表达变化：现场、日常、身体与社会行动进入艺术影像。",
  },
  {
    year: "1970s",
    device: "磁带 + CRT",
    title: "即时回放与闭路反馈",
    text: "磁带可重复播放，摄像机与电视机可形成闭路。艺术家不再只制作“片子”，而是把延迟、循环、信号故障和观看行为作为作品的一部分。",
    effect: "表达变化：时间可被折叠，屏幕可以观看屏幕。",
  },
  {
    year: "1980s",
    device: "录像墙 + 合成器",
    title: "画面成为可编排的电子材料",
    text: "多台监视器、视频合成与剪辑设备扩展了影像的色彩、节奏和并置能力；电视的广播语言被拆解为雕塑和装置。",
    effect: "表达变化：单一画框变成多个同时发生的视觉声部。",
  },
  {
    year: "1990s",
    device: "数字投影",
    title: "影像离开电视机表面",
    text: "更明亮的投影与数字后期让影像能覆盖墙面、悬置在空间中，并以慢动作和多声道声音包围观众。",
    effect: "表达变化：观看从“面对屏幕”变成“进入影像环境”。",
  },
  {
    year: "2000s–",
    device: "软件 + 网络 + 传感器",
    title: "录像扩展为实时系统",
    text: "数字文件、直播、计算机视觉与交互装置让作品可以持续生成、响应身体并在多个终端分布。",
    effect: "表达变化：作品不必固定完成，而可作为规则、界面和关系运行。",
  },
];

const sources = [
  ["MoMA｜Video Spaces：录像艺术与 Portapak 的早期语境", "https://www.moma.org/interactives/exhibitions/1995/videospaces/london.html"],
  ["白南准艺术中心｜TV Buddha（馆藏页）", "https://njpart.ggcf.kr/collections/205"],
  ["MoMA｜Joan Jonas, Vertical Roll, 1972", "https://www.moma.org/collection/works/110544"],
  ["Smithsonian American Art Museum｜Vertical Roll（图像与作品信息）", "https://americanart.si.edu/artwork/vertical-roll-76582"],
  ["The Bohen Foundation｜Bill Viola, The Crossing", "https://www.bohen.org/project/bill-viola-crossing"],
  ["Dallas Museum of Art｜The Crossing（馆藏与图像）", "https://next.staging.dma.org/art/collection/object/5319379"],
  ["Glenstone｜Pipilotti Rist, Ever Is Over All", "https://www.glenstone.org/artworks/ever-is-over-all"],
  ["Guggenheim Bilbao｜Ever is Over All 专题页", "https://www.guggenheim-bilbao.eus/en/exhibitions/ever-is-over-all-pipilotti-rist"],
  ["SFMOMA｜Bill Viola 回顾展资料", "https://www.sfmoma.org/exhibition/bill-viola/"],
] as const;

function Node({ id, kicker, title, className = "", children }: NodeProps) {
  return (
    <article id={id} data-node data-node-title={title} className={`story-node ${className}`}>
      <div className="node-header">
        <span className="node-kicker">{kicker}</span>
        <span className="node-timecode" aria-hidden="true">REC ● 00:{String(id.length * 7).padStart(2, "0")}:12</span>
      </div>
      <h2>{title}</h2>
      {children}
    </article>
  );
}

function Citation({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <a className="citation" href={href} target="_blank" rel="noreferrer">
      {children}<span aria-hidden="true"> ↗</span>
    </a>
  );
}

function Figure({ src, alt, caption, href, className = "" }: { src: string; alt: string; caption: string; href: string; className?: string }) {
  const [failed, setFailed] = useState(false);
  return (
    <figure className={`art-figure ${className}`}>
      {failed ? (
        <div className="image-fallback" role="img" aria-label={alt}>
          <span>IMAGE SIGNAL LOST</span><b>请通过下方官方来源查看作品图</b>
        </div>
      ) : (
        <img src={src} alt={alt} loading="lazy" onError={() => setFailed(true)} />
      )}
      <figcaption>{caption} · <a href={href} target="_blank" rel="noreferrer">来源 ↗</a></figcaption>
    </figure>
  );
}

function TimelineLab() {
  const [index, setIndex] = useState(0);
  const item = timeline[index];
  return (
    <div className="timeline-lab" aria-label="录像媒介发展时间轴">
      <div className="timeline-readout">
        <div><span>{item.year}</span><small>{item.device}</small></div>
        <h3>{item.title}</h3>
        <p>{item.text}</p>
        <strong>{item.effect}</strong>
      </div>
      <label className="range-field">
        <span>拖动时间轴</span>
        <input type="range" min="0" max={timeline.length - 1} value={index} onChange={(event) => setIndex(Number(event.target.value))} />
      </label>
      <div className="timeline-ticks">
        {timeline.map((entry, entryIndex) => (
          <button key={entry.year} className={entryIndex === index ? "active" : ""} onClick={() => setIndex(entryIndex)} aria-label={`切换到 ${entry.year}`}>
            <i />{entry.year}
          </button>
        ))}
      </div>
    </div>
  );
}

function LoopLab() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [start, setStart] = useState(0.8);
  const [end, setEnd] = useState(4.8);
  const [playing, setPlaying] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const onTime = () => {
      if (video.currentTime >= end || video.currentTime < start - 0.08) video.currentTime = start;
    };
    video.addEventListener("timeupdate", onTime);
    return () => video.removeEventListener("timeupdate", onTime);
  }, [start, end]);

  const toggle = async () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      if (video.currentTime < start || video.currentTime > end) video.currentTime = start;
      await video.play();
      setPlaying(true);
    } else {
      video.pause();
      setPlaying(false);
    }
  };

  return (
    <div className="experiment-grid">
      <div className="video-shell">
        {failed ? <img src="/media/original-poster.jpg" alt="原创录像实验的静态关键帧" /> : (
          <video ref={videoRef} muted playsInline poster="/media/original-poster.jpg" onError={() => setFailed(true)}>
            <source src="/media/original-loop.mp4" type="video/mp4" />
          </video>
        )}
        <span className="video-stamp">ORIGINAL STUDY / 06 SEC</span>
      </div>
      <div className="experiment-controls">
        <div className="loop-numbers"><b>{start.toFixed(1)}s</b><span>LOOP WINDOW</span><b>{end.toFixed(1)}s</b></div>
        <label className="range-field"><span>循环起点</span><input type="range" min="0" max="5.2" step="0.1" value={start} onChange={(e) => setStart(Math.min(Number(e.target.value), end - 0.4))} /></label>
        <label className="range-field"><span>循环终点</span><input type="range" min="0.6" max="6" step="0.1" value={end} onChange={(e) => setEnd(Math.max(Number(e.target.value), start + 0.4))} /></label>
        <button className="control-button" onClick={toggle}>{playing ? "暂停循环" : "播放所选区间"}</button>
        <p className="lab-note">同一动作因为切点不同，可从“完整事件”变成“犹豫”“冲突”或“无法结束”。录像艺术把剪辑点变成观念。</p>
      </div>
    </div>
  );
}

function FeedbackLab() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [camera, setCamera] = useState(false);
  const [message, setMessage] = useState("当前：预录制素材模拟闭路反馈");

  const stopCamera = useCallback(() => {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    const video = videoRef.current;
    if (video) {
      video.srcObject = null;
      video.src = "/media/original-loop.mp4";
      video.loop = true;
      void video.play().catch(() => undefined);
    }
    setCamera(false);
    setMessage("当前：预录制素材模拟闭路反馈");
  }, []);

  const startCamera = async () => {
    if (!navigator.mediaDevices?.getUserMedia) {
      setMessage("此浏览器不支持摄像头模式，已保留预录制演示。");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.src = "";
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setCamera(true);
      setMessage("摄像头仅在本机实时显示；不录制、不上传。");
    } catch {
      setMessage("未获得摄像头权限，继续使用预录制演示。");
    }
  };

  useEffect(() => () => streamRef.current?.getTracks().forEach((track) => track.stop()), []);

  return (
    <div className="feedback-lab">
      <div className="feedback-stage">
        <div className="screen screen-one"><div className="screen screen-two"><div className="screen screen-three">
          <video ref={videoRef} src="/media/original-loop.mp4" muted loop autoPlay playsInline poster="/media/original-poster.jpg" />
        </div></div></div>
        <span className="feedback-arrow">摄像机 → 屏幕 → 摄像机</span>
      </div>
      <div className="feedback-copy">
        <h3>你不是在看一张图，而是在进入一个回路。</h3>
        <p>闭路系统让“现在”几乎立刻返回屏幕。自我观看产生分裂：身体在现场，电子替身也在现场，而且会继续被下一次观看捕获。</p>
        <div className="button-row">
          {!camera ? <button className="control-button" onClick={startCamera}>主动开启本机摄像头</button> : <button className="control-button danger" onClick={stopCamera}>关闭摄像头</button>}
        </div>
        <small className="privacy-note">{message}</small>
      </div>
    </div>
  );
}

function MiniCharacteristicLabs() {
  const [pose, setPose] = useState(0);
  const [glitch, setGlitch] = useState(30);
  const [viewer, setViewer] = useState(1);
  return (
    <div className="mini-labs">
      <div className="mini-lab">
        <span className="mini-label">身体 / 镜头</span>
        <div className={`body-study pose-${pose}`}><i /><i /><i /></div>
        <button onClick={() => setPose((pose + 1) % 3)}>改变取景：{["全身", "局部", "遮挡"][pose]}</button>
        <p>镜头不是透明窗口；取景会切割、重复或暴露身体。</p>
      </div>
      <div className="mini-lab">
        <span className="mini-label">媒介故障</span>
        <div className="glitch-study" style={{ "--glitch": `${glitch / 10}px` } as React.CSSProperties}><b>SYNC</b><i /></div>
        <input aria-label="调整故障强度" type="range" min="0" max="100" value={glitch} onChange={(e) => setGlitch(Number(e.target.value))} />
        <p>失同步、噪点与断裂暴露了媒介本身，而不是遮掩它。</p>
      </div>
      <div className="mini-lab">
        <span className="mini-label">观众 / 位置</span>
        <div className="viewer-study"><i className={`viewer viewer-${viewer}`} /><span>SCREEN</span></div>
        <div className="segmented"><button onClick={() => setViewer(0)}>侧面</button><button onClick={() => setViewer(1)}>正面</button><button onClick={() => setViewer(2)}>穿行</button></div>
        <p>{["侧看时，屏幕成为空间中的物体。", "正面观看强化单一画框。", "穿行让身体决定叙事顺序。"][viewer]}</p>
      </div>
    </div>
  );
}

function MultiScreenLab() {
  const [count, setCount] = useState(1);
  const [playing, setPlaying] = useState(false);
  const videos = useRef<(HTMLVideoElement | null)[]>([]);

  const toggle = async () => {
    if (playing) videos.current.forEach((video) => video?.pause());
    else {
      videos.current.forEach((video) => { if (video) video.currentTime = 0; });
      await Promise.all(videos.current.slice(0, count).map((video) => video?.play().catch(() => undefined)));
    }
    setPlaying(!playing);
  };

  useEffect(() => {
    videos.current.forEach((video, index) => {
      if (!video) return;
      if (index >= count) video.pause();
      else if (playing) { video.currentTime = 0; void video.play().catch(() => undefined); }
    });
  }, [count, playing]);

  return (
    <div className="multiscreen-lab">
      <div className={`screen-grid screens-${count}`}>
        {[0, 1, 2].slice(0, count).map((index) => (
          <video key={`${count}-${index}`} ref={(node) => { videos.current[index] = node; }} muted loop playsInline poster="/media/original-poster.jpg" src="/media/original-loop.mp4" />
        ))}
      </div>
      <div className="screen-controls">
        <div className="segmented" aria-label="选择屏幕数量">
          {[1, 2, 3].map((value) => <button className={count === value ? "active" : ""} key={value} onClick={() => setCount(value)}>{value} 屏</button>)}
        </div>
        <button className="control-button" onClick={toggle}>{playing ? "暂停" : "同步播放"}</button>
        <p>{count === 1 ? "单屏集中注意：画面像一个完整句子。" : count === 2 ? "双屏制造比较：两幅画面既同步又互相质疑。" : "三屏形成空间语法：视线必须选择，叙事不再只有一个中心。"}</p>
      </div>
    </div>
  );
}

function WorkFacts({ items }: { items: [string, string][] }) {
  return <dl className="work-facts">{items.map(([term, value]) => <div key={term}><dt>{term}</dt><dd>{value}</dd></div>)}</dl>;
}

export default function VideoArtExperience() {
  const [presentation, setPresentation] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [currentNode, setCurrentNode] = useState(0);
  const [tocOpen, setTocOpen] = useState(false);
  const [nodeTitles, setNodeTitles] = useState<string[]>([]);
  const nodesRef = useRef<HTMLElement[]>([]);

  useEffect(() => {
    nodesRef.current = Array.from(document.querySelectorAll<HTMLElement>("[data-node]"));
    setNodeTitles(nodesRef.current.map((node) => node.dataset.nodeTitle || "未命名节点"));
    const observer = new IntersectionObserver((entries) => {
      const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (visible) setCurrentNode(nodesRef.current.indexOf(visible.target as HTMLElement));
    }, { threshold: [0.25, 0.55, 0.8], rootMargin: "-18% 0px -42%" });
    nodesRef.current.forEach((node) => observer.observe(node));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    document.documentElement.dataset.reducedMotion = reducedMotion ? "true" : "false";
  }, [reducedMotion]);

  const goTo = useCallback((index: number) => {
    const next = Math.max(0, Math.min(nodesRef.current.length - 1, index));
    nodesRef.current[next]?.scrollIntoView({ behavior: reducedMotion ? "auto" : "smooth", block: "start" });
    setCurrentNode(next);
  }, [reducedMotion]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (!presentation) return;
      const target = event.target as HTMLElement;
      if (["INPUT", "TEXTAREA", "SELECT", "BUTTON"].includes(target.tagName)) return;
      if (["ArrowRight", "ArrowDown", "PageDown", " "].includes(event.key)) { event.preventDefault(); goTo(currentNode + 1); }
      if (["ArrowLeft", "ArrowUp", "PageUp"].includes(event.key)) { event.preventDefault(); goTo(currentNode - 1); }
      if (event.key === "Home") { event.preventDefault(); goTo(0); }
      if (event.key === "End") { event.preventDefault(); goTo(nodesRef.current.length - 1); }
      if (event.key === "Escape") setPresentation(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [presentation, currentNode, goTo]);

  return (
    <div className={`${presentation ? "presentation-mode" : ""} site-shell`}>
      <div className="scanlines" aria-hidden="true" />
      <header className="site-header">
        <a className="brand" href="#home"><span>VIDEO / ART</span><b>影像回路研究所</b></a>
        <nav aria-label="章节导航">
          {chapterLinks.map(([label, href]) => <a key={href} href={`#${href}`}>{label}</a>)}
        </nav>
        <div className="header-actions">
          <button onClick={() => setReducedMotion(!reducedMotion)} aria-pressed={reducedMotion}>{reducedMotion ? "静态版：开" : "减少动态"}</button>
          <button className="present-button" onClick={() => setPresentation(!presentation)} aria-pressed={presentation}>{presentation ? "退出演示" : "演示模式"}</button>
        </div>
      </header>

      <main>
        <section id="home" className="chapter hero-chapter" aria-labelledby="hero-title">
          <Node id="node-01" kicker="01 / OPENING SIGNAL" title="录像艺术：当影像开始观看自己" className="hero-node">
            <div className="hero-grid">
              <div className="hero-copy">
                <p className="hero-thesis">摄像机从记录世界的工具，变成观察<strong>时间、身体与观看行为</strong>的艺术媒介。</p>
                <p className="classline">第 X 组 · 数媒261314 · by KOU JINXUAN，LI XUE，JIANG ZHONG</p>
                <div className="hero-buttons"><a className="primary-cta" href="#history">开始探索 <span>↓</span></a><button onClick={() => setPresentation(true)}>进入演示模式</button></div>
              </div>
              <div className="hero-video-stack" aria-label="原创录像质感视觉片段">
                <div className="depth-screen back" /><div className="depth-screen middle" />
                <video autoPlay muted loop playsInline poster="/media/original-poster.jpg"><source src="/media/original-loop.mp4" type="video/mp4" /></video>
                <span className="hero-video-label">ORIGINAL SIGNAL · NOT AN ARTWORK CLIP</span>
              </div>
            </div>
            <div className="hero-foot"><span>7 CHAPTERS</span><span>28 STUDY NODES</span><span>4 INTERACTIVE LABS</span></div>
          </Node>
          <Node id="node-02" kicker="02 / RESEARCH MAP" title="我们要回答的，不只是“它拍了什么”">
            <div className="question-grid">
              {["录像艺术是什么？它为何不等同于电影或短视频？", "时间、反馈、身体、故障和空间如何成为材料？", "作品形式怎样服务主题，而不是只做视觉包装？", "这些方法如何转化为今天的数字媒体创作？"].map((question, index) => <div key={question}><span>0{index + 1}</span><h3>{question}</h3></div>)}
            </div>
            <p className="big-note">操作提示：自由滚动适合自学；“演示模式”可用方向键按节点推进，右下角会显示当前位置。</p>
          </Node>
        </section>

        <section id="history" className="chapter">
          <div className="chapter-title"><span>CHAPTER 01</span><h1>发展脉络</h1><p>技术不是背景，而是改变艺术语言的条件。</p></div>
          <Node id="node-03" kicker="03 / DEFINITION" title="录像艺术不是“用摄像机拍出来的任何东西”">
            <div className="definition-grid">
              <p className="lead">录像艺术把电子影像的<strong>记录、传输、回放、信号与展示关系</strong>作为创作材料。作品可能是一段单频道录像，也可能是摄像机、屏幕、声音、空间和观众共同运行的系统。</p>
              <div className="comparison-strip">
                <div><b>传统电影</b><p>常以镜头叙事、剪辑和影院放映组织封闭作品。</p></div>
                <div className="accent"><b>录像艺术</b><p>可实时、循环、多屏、装置化；媒介与观看行为本身就是主题。</p></div>
                <div><b>一般短视频</b><p>多服从平台时长、信息效率、社交传播和算法节奏。</p></div>
              </div>
            </div>
            <p className="source-line">历史语境依据 <Citation href="https://www.moma.org/interactives/exhibitions/1995/videospaces/london.html">MoMA《Video Spaces》策展资料</Citation></p>
          </Node>
          <Node id="node-04" kicker="04 / ORIGIN" title="便携录像让“现在”第一次容易被艺术家立即看见">
            <div className="origin-diagram">
              <div className="device camera"><i /><span>CAMERA</span></div><b>REC</b><div className="signal-line" /><div className="device deck"><i /><span>TAPE</span></div><b>PLAY</b><div className="signal-line" /><div className="device monitor"><i /><span>CRT</span></div>
            </div>
            <div className="two-col-text"><p>20 世纪 60 年代中期，便携录像设备进入消费市场。MoMA 策展人 Barbara London 指出，在此之前录像主要受限于照明充足的电视演播室、笨重的 2 英寸磁带设备和工程团队。</p><p>可负担、可携带、能在较低照度拍摄的设备，令艺术家能够在工作室、街道和表演现场快速试验；录像由广播工业的专属技术转为个人可以批判、扰动和重新组织的媒介。</p></div>
          </Node>
          <Node id="node-05" kicker="05 / DRAGGABLE TIMELINE" title="拖动技术史，看艺术表达如何改变">
            <TimelineLab />
            <p className="source-line">时间线依据：<Citation href="https://www.moma.org/interactives/exhibitions/1995/videospaces/london.html">MoMA｜Video Spaces</Citation>；后续阶段为对代表作品展示方式的归纳。</p>
          </Node>
          <Node id="node-06" kicker="06 / MEDIA SHIFT" title="媒介变化的核心：影像从对象变成环境">
            <div className="media-evolution">
              {[['摄像机','捕捉现场','谁控制视角？'],['电视机','即时回放','谁在看谁？'],['录像带','复制与循环','事件何时结束？'],['投影','放大与沉浸','身体站在哪里？'],['软件系统','实时运算','作品何时完成？']].map(([name, verb, question], index) => <div key={name}><span>0{index + 1}</span><b>{name}</b><p>{verb}</p><small>{question}</small></div>)}
            </div>
          </Node>
        </section>

        <section id="characteristics" className="chapter">
          <div className="chapter-title"><span>CHAPTER 02</span><h1>核心特点</h1><p>录像艺术把“如何看”变成作品内容。</p></div>
          <Node id="node-07" kicker="07 / SIX FEATURES" title="六个关键词，构成录像艺术的基本语法">
            <div className="feature-index">
              {[['时间与循环','事件可被重复、延迟、减速。'],['实时反馈','观看在同一时刻返回现场。'],['身体表演','镜头切割、复制或审视身体。'],['媒介故障','噪点和失同步显露技术结构。'],['观众参与','观看者可能被系统捕获或触发。'],['空间化观看','多屏与投影让身体决定叙事。']].map(([title, text], index) => <div key={title}><span>{String(index + 1).padStart(2,'0')}</span><h3>{title}</h3><p>{text}</p></div>)}
            </div>
          </Node>
          <Node id="node-08" kicker="08 / LOOP LAB" title="时间与循环：重复不是回到原点，而是改变意义">
            <LoopLab />
          </Node>
          <Node id="node-09" kicker="09 / FEEDBACK LAB" title="实时反馈：影像开始观看自己的生成过程">
            <FeedbackLab />
          </Node>
          <Node id="node-10" kicker="10 / BODY & CAMERA" title="身体、故障与观众位置都可以被操作">
            <MiniCharacteristicLabs />
          </Node>
          <Node id="node-11" kicker="11 / GLITCH" title="故障美学不是滤镜，而是让系统暴露">
            <div className="glitch-principles">
              <div><b>从错误到材料</b><p>滚屏、扫描线、颜色偏移、磁带噪声揭示影像是被设备生成的信号，而非无缝现实。</p></div>
              <div><b>从装饰到结构</b><p>有效的故障必须影响节奏、身体或叙事规则；仅叠加噪点会把媒介批判降格为复古包装。</p></div>
              <div><b>从控制到协商</b><p>艺术家设置系统，但也允许设备的限制、误差与不稳定参与创作。</p></div>
            </div>
          </Node>
          <Node id="node-12" kicker="12 / VIEWER & SPACE" title="观看不是终点：观众的位置会重写作品">
            <div className="space-map"><div className="projector">PROJECTOR</div><span className="beam" /><div className="projection">IMAGE</div><i className="human h-one" /><i className="human h-two" /><i className="human h-three" /></div>
            <p className="lead centered">当影像进入展厅，观众必须靠近、绕行、回头或在两个画面之间选择。观看时间不再由座位和片长单独决定，而由身体路径共同完成。</p>
          </Node>
        </section>

        <section id="forms" className="chapter">
          <div className="chapter-title"><span>CHAPTER 03</span><h1>表现形式</h1><p>形式不是容器；每一种展示方式都规定一种观看关系。</p></div>
          <Node id="node-13" kicker="13 / FORM MATRIX" title="五种形式，五种不同的观看机制">
            <div className="form-matrix">
              <div className="matrix-head"><span>形式</span><span>影像组织</span><span>观众角色</span><span>适合的问题</span></div>
              {[['单频道录像','一个时间流','集中观看','节奏、身体、叙事'],['多频道影像','并行或对照','比较与选择','多视角、冲突、同步'],['闭路电视','现场传输','被看见的观看者','监控、自我、反馈'],['行为录像','身体与镜头协作','见证动作','身份、性别、权力'],['录像装置','影像 + 物体 + 空间','移动中的参与者','尺度、沉浸、场域']].map(row => <div className="matrix-row" key={row[0]}>{row.map(cell => <span key={cell}>{cell}</span>)}</div>)}
            </div>
          </Node>
          <Node id="node-14" kicker="14 / SINGLE CHANNEL" title="单频道录像：把一个屏幕内部的时间压到最紧">
            <div className="form-story"><div className="single-screen"><span>ONE SIGNAL</span><i /></div><div><h3>优势</h3><p>观看焦点明确，剪辑、声音与持续时间可形成严密结构；容易在显示器、投影或线上播放。</p><h3>局限也是语言</h3><p>画框会切割身体，固定播放顺序会控制观看节奏。艺术家可以把这种控制直接变成主题。</p><strong>案例联想：《Vertical Roll》用单频道结构让故障条持续支配身体与声音。</strong></div></div>
          </Node>
          <Node id="node-15" kicker="15 / MULTI & CCTV" title="多频道与闭路电视：画面之间开始发生关系">
            <div className="two-form-cards"><div><span>01</span><h3>多频道</h3><p>两个或更多影像同时出现。意义来自同步、错位、互补与观众无法一次看全的缺口。</p><small>关键词：并置 / 复调 / 空间剪辑</small></div><div><span>02</span><h3>闭路电视</h3><p>摄像机将现场画面送回同一空间。观众既是观看者，也是画面素材与系统变量。</p><small>关键词：实时 / 监控 / 自我反观</small></div></div>
          </Node>
          <Node id="node-16" kicker="16 / PERFORMANCE & INSTALLATION" title="行为录像与录像装置：让身体和展厅共同“剪辑”">
            <div className="form-story reverse"><div className="installation-sketch"><div className="wall-a"/><div className="wall-b"/><i className="moving-viewer"/></div><div><p className="lead">行为录像不是简单保存表演；镜头可能是对手、镜子或限制条件。录像装置也不是把视频放大，而是设计观众进入、停留、转身与离开的路径。</p><ul className="clean-list"><li>镜头取景决定身体如何被识别。</li><li>屏幕尺度决定影像是对象、人物还是环境。</li><li>声音方向决定观众先看哪里、靠近什么。</li></ul></div></div>
          </Node>
        </section>

        <section id="works" className="chapter works-chapter">
          <div className="chapter-title"><span>CHAPTER 04</span><h1>代表作品</h1><p>每件作品都回答：形式如何服务主题？</p></div>
          <Node id="node-17" kicker="17 / CASE 01" title="白南准《TV Buddha》：一个无法结束的自我观看回路">
            <div className="work-grid">
              <Figure src="/artworks/tv-buddha.jpg" alt="白南准《TV Buddha》装置：佛像面对电视与闭路摄像机" caption="白南准，《TV Buddha》，1974（白南准艺术中心馆藏版本标注为 1974/2002）" href="https://njpart.ggcf.kr/collections/205" />
              <div><WorkFacts items={[["作者","白南准 Nam June Paik"],["年份","1974；该馆藏版本 1974（2002）"],["媒介","石灰岩佛像、CRT 电视机、闭路摄像机"],["展示方式","佛像与电视相对；摄像机把佛像实时传回屏幕；尺寸可变"]]} /><p className="work-note">作品存在多个版本，装置材料与年代标注可能随馆藏版本不同。本页明确采用白南准艺术中心的馆藏记录。</p></div>
            </div>
          </Node>
          <Node id="node-18" kicker="18 / FORM SERVES IDEA" title="《TV Buddha》：形式把“谁在观看谁”变成现场问题">
            <div className="analysis-grid">
              <div><span>画面</span><h3>古老雕像对着电子替身</h3><p>“东方智慧”与大众媒体的并置既幽默又不安：冥想可能变成自恋，电视也可能变成反思工具。</p></div>
              <div><span>时间</span><h3>没有预制片长，只有持续现在</h3><p>闭路画面与佛像同时存在，作品不是过去事件的记录，而是每次展出都重新发生的现在。</p></div>
              <div><span>观众</span><h3>靠近屏幕，观众也可能进入画面</h3><p>白南准艺术中心指出，观众俯身观看佛像所见时，会出现在电视中。观看者因此被系统反看。</p></div>
              <div className="conclusion-card"><b>形式 → 主题</b><p>闭路摄像机不是技术炫技；它把自我反观、媒介凝视和观众参与连接为同一个实时回路。</p></div>
            </div>
            <p className="source-line"><Citation href="https://njpart.ggcf.kr/collections/205">白南准艺术中心｜作品说明与馆藏信息</Citation></p>
          </Node>
          <Node id="node-19" kicker="19 / CASE 02" title="琼·乔纳斯《Vertical Roll》：让电视故障成为身体的节拍器">
            <div className="work-grid reverse">
              <div><WorkFacts items={[["作者","琼·乔纳斯 Joan Jonas"],["年份","1972"],["媒介","单频道录像，黑白，有声"],["时长","19 分 38 秒"],["展示方式","单屏播放；最终录像由第二台摄像机拍摄发生垂直滚屏的监视器"]]} /><p className="work-note">作品图像由 Smithsonian American Art Museum 馆藏页提供，版权归艺术家及相关权利方；本项目为课程研究使用并保留完整署名。</p></div>
              <div className="frame-sequence">{[1,2,3].map(n => <Figure key={n} src={`/artworks/vertical-roll-${n}.jpg`} alt={`《Vertical Roll》关键帧 ${n}`} caption={`琼·乔纳斯，《Vertical Roll》，1972，关键帧 ${n}`} href="https://americanart.si.edu/artwork/vertical-roll-76582" />)}</div>
            </div>
          </Node>
          <Node id="node-20" kicker="20 / FORM SERVES IDEA" title="《Vertical Roll》：故障切割身体，也拒绝顺从的女性影像">
            <div className="analysis-grid">
              <div><span>画面</span><h3>滚动黑条不断把身体打断</h3><p>人物不是被完整、平滑地呈现，而是在画框边缘、跳动与断裂中出现。电视图像的机械结构因此可见。</p></div>
              <div><span>声音</span><h3>敲击声与滚屏节奏绑定</h3><p>MoMA 说明，乔纳斯另行录制敲击木块的声音并加入录像。声音把视觉故障变成身体能够感到的脉冲。</p></div>
              <div><span>身体</span><h3>表演主动适应并对抗机器</h3><p>她围绕滚动条组织动作，让故障成为合作者；被电视观看的女性身体不再只是可消费的完整形象。</p></div>
              <div className="conclusion-card"><b>形式 → 主题</b><p>单频道、滚屏故障、身体碎片与重复敲击共同揭露电视幻觉的机械基础，并把观看权重新交回表演者。</p></div>
            </div>
            <p className="source-line"><Citation href="https://www.moma.org/collection/works/110544">MoMA｜作品机制与艺术家说明</Citation> <Citation href="https://americanart.si.edu/artwork/vertical-roll-76582">Smithsonian｜作品信息与图像</Citation></p>
          </Node>
          <Node id="node-21" kicker="21 / CASE 03" title="比尔·维奥拉《The Crossing》：让极慢时间把图像变成仪式">
            <div className="work-grid">
              <div className="crossing-pair"><Figure src="/artworks/the-crossing-1.jpg" alt="比尔·维奥拉《The Crossing》水面或装置关键帧" caption="比尔·维奥拉，《The Crossing》，1996，图像 1" href="https://next.staging.dma.org/art/collection/object/5319379" /><Figure src="/artworks/the-crossing-2.jpg" alt="比尔·维奥拉《The Crossing》火焰或装置关键帧" caption="比尔·维奥拉，《The Crossing》，1996，图像 2" href="https://next.staging.dma.org/art/collection/object/5319379" /></div>
              <div><WorkFacts items={[["作者","比尔·维奥拉 Bill Viola"],["年份","1996"],["媒介","双频道彩色视频装置，四声道声音"],["时长","10 分 57 秒"],["展示方式","大型双面屏幕置于暗室；水与火两段同步影像投射在相背两面"]]} /><p className="work-note">Bohen Foundation 记录其为两屏录像装置，通常以双面屏展示；作品现属古根海姆博物馆收藏。</p></div>
            </div>
          </Node>
          <Node id="node-22" kicker="22 / FORM SERVES IDEA" title="《The Crossing》：观众必须移动，才能在火与水之间完成作品">
            <div className="analysis-grid">
              <div><span>时间</span><h3>极慢动作把瞬间拉成冥想</h3><p>人物从黑暗中走近，水滴与小火逐渐扩张，最终吞没身体。减速迫使观众注意变化的细部，而不是追逐情节。</p></div>
              <div><span>空间</span><h3>两面屏幕拒绝一次看全</h3><p>火与水分别位于屏幕两侧。观众必须绕行；当看见一面时，另一面正在不可见处同步发生。</p></div>
              <div><span>声音</span><h3>四声道把元素变成身体经验</h3><p>水流与火焰的声压扩展到画面之外，使观看接近仪式性的环境，而非远距离图像消费。</p></div>
              <div className="conclusion-card"><b>形式 → 主题</b><p>慢动作、巨大尺度、背对背投影和包围声音，把“毁灭 / 净化、死亡 / 再生”的对置转化为观众必须用时间与身体经历的仪式。</p></div>
            </div>
            <p className="source-line"><Citation href="https://www.bohen.org/project/bill-viola-crossing">Bohen Foundation｜展示结构与作品信息</Citation> <Citation href="https://next.staging.dma.org/art/collection/object/5319379">Dallas Museum of Art｜馆藏阐释</Citation></p>
          </Node>
          <Node id="node-23" kicker="23 / CASE 04" title="皮皮洛蒂·瑞斯特《Ever Is Over All》：柔美图像里的破坏动作">
            <div className="work-grid reverse">
              <div><WorkFacts items={[["作者","皮皮洛蒂·瑞斯特 Pipilotti Rist"],["年份","1997"],["媒介","双频道录像，重叠投影，彩色与声音；声音合作 Anders Guggisberg"],["展示方式","两幅大尺幅影像在墙面重叠：街头行走与花朵特写并置"]]} /><p className="work-note">Glenstone 馆藏记录作品为双频道、重叠投影；Guggenheim Bilbao 对两组画面与慢化声轨有详细说明。</p></div>
              <Figure src="/artworks/ever-is-over-all.jpg" alt="皮皮洛蒂·瑞斯特《Ever Is Over All》双频道投影装置" caption="皮皮洛蒂·瑞斯特，《Ever Is Over All》，1997，双频道重叠投影" href="https://www.glenstone.org/artworks/ever-is-over-all" />
            </div>
          </Node>
          <Node id="node-24" kicker="24 / FORM SERVES IDEA" title="《Ever Is Over All》：让暴力以梦游般的节奏进入公共空间">
            <div className="analysis-grid">
              <div><span>画面</span><h3>花朵同时是植物、图像与武器</h3><p>一侧是女性轻快行走并用巨大花朵击碎车窗；另一侧是饱和的花朵近景。重叠让破坏与生长难以分开。</p></div>
              <div><span>时间 / 声音</span><h3>慢动作与慢化声轨制造不真实的轻盈</h3><p>动作没有新闻画面的惊吓节奏，而像梦游。速度与声轨改变了破坏行为的情绪含义。</p></div>
              <div><span>女性视角</span><h3>公共空间中的身体不再顺从</h3><p>微笑、浅蓝裙装、鲜花与砸窗形成冲突；作品拒绝把女性行动简单归类为温柔或暴力。</p></div>
              <div className="conclusion-card"><b>形式 → 主题</b><p>双频道重叠、饱和色彩、慢动作和声轨共同建立“魔幻现实”：视觉愉悦包裹越界行动，让观众重新判断性别、权力与公共秩序。</p></div>
            </div>
            <p className="source-line"><Citation href="https://www.glenstone.org/artworks/ever-is-over-all">Glenstone｜馆藏信息</Citation> <Citation href="https://www.guggenheim-bilbao.eus/en/exhibitions/ever-is-over-all-pipilotti-rist">Guggenheim Bilbao｜作品阐释</Citation></p>
          </Node>
        </section>

        <section id="impact" className="chapter">
          <div className="chapter-title"><span>CHAPTER 05–06</span><h1>数字媒体艺术的影响</h1><p>录像艺术留下的不是一种复古风格，而是一组仍然有效的方法。</p></div>
          <Node id="node-25" kicker="25 / MULTI-SCREEN LAB" title="多屏实验：空间本身就是剪辑台">
            <MultiScreenLab />
          </Node>
          <Node id="node-26" kicker="26 / METHOD TRANSFER" title="五种可借鉴方法，以及具体创作应用">
            <div className="method-cards">
              {[['循环影像','不是让片段无限播放，而是通过重复制造新的情绪或因果。','校园门禁影像：只循环“刷卡—失败—再刷卡”，把日常动作变成制度压力。'],['故障语言','让错误暴露算法、设备或传输的边界。','毕业档案网页：当资料缺失时，不用默认占位图，而以数据断裂生成可读的视觉噪声。'],['实时反馈','让观众看到自己的动作如何进入系统。','互动肖像：摄像头仅在本机把观众轮廓延迟 3 秒叠回画面，讨论数字身份。'],['多屏叙事','用并行画面建立比较，而不是只增加屏幕数量。','城市声音装置：三屏分别显示同一地点的清晨、午间、午夜，让节奏和劳动关系并置。'],['沉浸空间','用尺度、声音方向和动线组织意义。','气候数据展：温度曲线投影在两面墙，观众穿过时听见对应年份的环境声变化。']].map(([name, idea, example], index) => <div key={name}><span>0{index + 1}</span><h3>{name}</h3><p>{idea}</p><strong>创作应用</strong><small>{example}</small></div>)}
            </div>
          </Node>
        </section>

        <section id="sources" className="chapter conclusion-chapter">
          <div className="chapter-title"><span>CHAPTER 07</span><h1>结论与资料来源</h1><p>从四件作品回到一个共同问题：观看如何被媒介重新组织？</p></div>
          <Node id="node-27" kicker="27 / COMPARISON" title="四件作品的横向比较">
            <div className="comparison-table-wrap"><table className="comparison-table"><thead><tr><th>作品</th><th>媒介机制</th><th>时间处理</th><th>空间形式</th><th>观众角色</th></tr></thead><tbody>
              <tr><th>TV Buddha</th><td>闭路摄像 + CRT</td><td>持续实时</td><td>雕像与屏幕相对</td><td>观看者也可能进入回路</td></tr>
              <tr><th>Vertical Roll</th><td>单频道 + 失同步</td><td>滚屏重复、节拍化</td><td>单屏集中</td><td>被迫感知画框与故障</td></tr>
              <tr><th>The Crossing</th><td>双频道 + 四声道</td><td>极慢动作、循环</td><td>双面巨幕、暗室</td><td>必须绕行才能比较</td></tr>
              <tr><th>Ever Is Over All</th><td>双频道重叠投影</td><td>慢动作、梦游节奏</td><td>大尺幅墙面融合</td><td>在愉悦与越界间判断</td></tr>
            </tbody></table></div>
            <p className="big-note">共同点：它们都不把录像当作透明记录，而是用设备、时间、空间和观看位置制造观念。</p>
          </Node>
          <Node id="node-28" kicker="28 / FINAL SIGNAL" title="结论：录像艺术改变了“作品在哪里”">
            <div className="final-grid">
              <div className="final-statement"><p>作品不只在画面里，也在<strong>播放的时间、屏幕的结构、观众的身体和系统的反馈</strong>中。</p><p>对数字媒体创作者最重要的借鉴，不是扫描线或复古噪点，而是先提出一个观看问题，再选择能够让观众亲自经历这个问题的技术结构。</p><a className="primary-cta" href="#home">回到开场信号 ↑</a></div>
              <div className="source-list"><h3>核验资料与图片来源</h3>{sources.map(([label, href], index) => <a href={href} target="_blank" rel="noreferrer" key={href}><span>{String(index + 1).padStart(2,"0")}</span>{label}<b>↗</b></a>)}</div>
            </div>
            <footer><p>课程研究网站 · 数媒261314 · 第 X 组</p><p>by KOU JINXUAN，LI XUE，JIANG ZHONG</p><p>原创交互演示素材不包含或仿制艺术家作品片段。</p></footer>
          </Node>
        </section>
      </main>

      <aside className="progress-hud" aria-live="polite">
        <button className="hud-title" onClick={() => setTocOpen(!tocOpen)} aria-expanded={tocOpen}><span>{String(currentNode + 1).padStart(2, "0")} / {String(nodeTitles.length || 28).padStart(2, "0")}</span><b>{nodeTitles[currentNode] || "录像艺术"}</b></button>
        <div className="progress-track"><i style={{ width: `${((currentNode + 1) / (nodeTitles.length || 28)) * 100}%` }} /></div>
        {presentation && <div className="arrow-controls"><button onClick={() => goTo(currentNode - 1)} aria-label="上一个节点">←</button><span>方向键讲解</span><button onClick={() => goTo(currentNode + 1)} aria-label="下一个节点">→</button></div>}
      </aside>

      {tocOpen && <div className="toc-panel"><div className="toc-head"><span>28 个讲解节点</span><button onClick={() => setTocOpen(false)}>关闭 ×</button></div><div className="toc-list">{nodeTitles.map((title, index) => <button className={index === currentNode ? "active" : ""} key={`${title}-${index}`} onClick={() => { goTo(index); setTocOpen(false); }}><span>{String(index + 1).padStart(2, "0")}</span>{title}</button>)}</div></div>}
    </div>
  );
}
