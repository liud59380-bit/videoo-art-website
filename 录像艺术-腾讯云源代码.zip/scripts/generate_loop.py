from pathlib import Path
import math
import os
import sys

from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "public" / "media"
OUT.mkdir(parents=True, exist_ok=True)

W, H, FPS, SECONDS = 960, 540, 30, 6

def font(size: int):
    for candidate in [
        "/System/Library/Fonts/PingFang.ttc",
        "/System/Library/Fonts/SFNSMono.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
    ]:
        if Path(candidate).exists():
            return ImageFont.truetype(candidate, size)
    return ImageFont.load_default()

mono = font(18)
title_font = font(46)

def frame_at(i: int) -> Image.Image:
    t = i / FPS
    phase = t / SECONDS * math.tau
    image = Image.new("RGB", (W, H), (7, 7, 10))
    draw = ImageDraw.Draw(image, "RGBA")
    for x in range(0, W, 48):
        draw.line((x, 0, x, H), fill=(255, 255, 255, 10), width=1)
    for y in range(0, H, 48):
        draw.line((0, y, W, y), fill=(255, 255, 255, 10), width=1)
    cx = W * (0.52 + math.sin(phase) * 0.03)
    cy = H * (0.48 + math.cos(phase * 0.7) * 0.035)
    for radius, alpha in [(210, 16), (160, 28), (112, 44)]:
        draw.ellipse((cx-radius, cy-radius, cx+radius, cy+radius), outline=(142,119,255,alpha), width=2)
    screen_w, screen_h = 440, 248
    sx = int(cx - screen_w / 2 + math.sin(phase * 2) * 8)
    sy = int(cy - screen_h / 2)
    draw.rectangle((sx, sy, sx + screen_w, sy + screen_h), fill=(13,12,18,245), outline=(198,190,231,150), width=2)
    inset = 26
    draw.rectangle((sx+inset, sy+inset, sx+screen_w-inset, sy+screen_h-inset), fill=(24,21,35,255))
    eye_y = sy + screen_h // 2
    eye_w = 150 + int(math.sin(phase) * 22)
    draw.ellipse((cx-eye_w, eye_y-50, cx+eye_w, eye_y+50), outline=(225,220,233,195), width=3)
    pupil = 22 + int((1+math.sin(phase*2))*5)
    draw.ellipse((cx-pupil, eye_y-pupil, cx+pupil, eye_y+pupil), fill=(184,170,255,235))
    draw.ellipse((cx-7, eye_y-7, cx+7, eye_y+7), fill=(8,8,10,255))
    roll_y = int((t / SECONDS) * (H + 80)) - 40
    draw.rectangle((0, roll_y, W, roll_y + 10), fill=(238,235,229,150))
    for offset in range(0, H, 4):
        draw.line((0, offset, W, offset), fill=(255,255,255,8), width=1)
    tc = f"REC  ●  00:00:{int(t):02d}:{int((t%1)*FPS):02d}"
    draw.text((30, 24), tc, font=mono, fill=(239,236,228,210))
    draw.text((30, H-42), "ORIGINAL SIGNAL STUDY / 2026", font=mono, fill=(184,170,255,210))
    title = "影像 / 回看 / 现在"
    box = draw.textbbox((0,0), title, font=title_font)
    draw.text((W-(box[2]-box[0])-34, H-66), title, font=title_font, fill=(238,234,226,55))
    return image.filter(ImageFilter.GaussianBlur(radius=0.12))

poster = frame_at(48)
poster.save(OUT / "original-poster.jpg", quality=90, optimize=True)

try:
    import imageio_ffmpeg
except ImportError:
    print("imageio_ffmpeg is required; install it into PYTHONPATH before running.", file=sys.stderr)
    raise

writer = imageio_ffmpeg.write_frames(
    str(OUT / "original-loop.mp4"),
    (W, H),
    fps=FPS,
    codec="libx264",
    pix_fmt_in="rgb24",
    pix_fmt_out="yuv420p",
    output_params=["-movflags", "+faststart", "-crf", "24", "-preset", "medium"],
)
writer.send(None)
for index in range(FPS * SECONDS):
    writer.send(frame_at(index).tobytes())
writer.close()
print(OUT / "original-loop.mp4")
